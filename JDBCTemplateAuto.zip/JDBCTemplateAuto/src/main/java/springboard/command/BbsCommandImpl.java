package springboard.command;

import org.springframework.ui.Model;

public interface BbsCommandImpl {

	void execute(Model model); 
}

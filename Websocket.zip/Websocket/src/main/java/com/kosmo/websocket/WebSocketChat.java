package com.kosmo.websocket;

import java.util.ArrayList;
import java.util.List;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.RemoteEndpoint.Basic;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;

@Controller
@ServerEndpoint("/EchoServer.do")
public class WebSocketChat {
	
	
	/*
	 해당 리스트 컬렉션은 클라이언트가 접속할때마다 세션 아이디를 저장하는 용도로 사용된다.
	 접속한 웹브라우저가 웹소켓을 지원해야 하며, 웹 브라우저를 닫으면 onclose가
	 호출된다.
	 */
	private static final List<Session> sessionList = new ArrayList<Session>();
	private static final Logger logger = LoggerFactory.getLogger(WebSocketChat.class);
	
	public WebSocketChat() {
		System.out.println("웹소켓 객체생성");
	}
	@OnOpen
	public void onOpen(Session session) {
		logger.info("새로운 session id="+session.getId());
		try {
			final Basic basic = session.getBasicRemote();
			logger.info("새로운 sessiongetBasicREmote="+basic);
			basic.sendText("대화방에 연결되었습니다.");
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		//클랄이언트가 접속하면 컬렉션에 추가한다.
		sessionList.add(session);
	}
	/*
	 자동으로 호출되진 않고, 서버로 메세지가 왔을대 해당메서드를 호출한다.
	 현재 접속한 모든 클라이언트에게 메세지를 전송한다.
	 */
	private void sendAllSessionToMessage(Session self, String message) {
		try {
			//List컬렉션에 저장된 클라이언트 만큼 반복한다.
			for(Session session : WebSocketChat.sessionList) {
				//메세지를 보낸 자신을 제외한 나머지에게 메세지를 전송한다.
				if(!self.getId().equals(session.getId())) {
					//sendText()메서드를 통해 클라이언트에게 메세지를 전송한다.
					session.getBasicRemote().sendText(message);
				}
			}
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	@OnMessage
	public void onMessage(String message, Session session) {
		
		try {
			final Basic basic = session.getBasicRemote();
			logger.info("메세지도착:"+basic+"="+message);
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		//클라이언트 전체에게 메세지 전송
		sendAllSessionToMessage(session,message);
	}
	
	//채팅중 오류가 발생했을ㄸ
	@OnError
	public void onError(Throwable e, Session session) {
		System.out.println(e.getMessage());
	}
	//클라이언트가 접속을 종료했을대 
	@OnClose
	public void onClose(Session session) {
		sessionList.remove(session);
		logger.info("접속종료:"+session.getId());
	}
	
	
	
}
